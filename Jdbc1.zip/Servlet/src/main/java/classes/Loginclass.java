package classes;


public class Loginclass {
	
	private String username =null;
	
	public Loginclass() {
		// TODO Auto-generated constructor stub
		
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
}

