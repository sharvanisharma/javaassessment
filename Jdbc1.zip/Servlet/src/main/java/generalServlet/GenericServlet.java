package generalServlet;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GenericServlet
 */
public class GenericServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenericServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		RequestDispatcher rd = request.getRequestDispatcher("GeneralServlet.html");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String[] languageKnown = request.getParameterValues("checkbook");
		PrintWriter out = response.getWriter();
//		rd.forward(request, response);
		out.println("Username "+username+"\nPassword "+password);
		if(languageKnown != null) {
			for(int i=0; i<languageKnown.length; i++) {
				out.println(languageKnown[i]);
			}
		}else {
			out.println("No Language found");
		}
	}

}
