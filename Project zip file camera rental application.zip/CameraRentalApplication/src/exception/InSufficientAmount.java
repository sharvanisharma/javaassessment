package exception;

public class InSufficientAmount extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InSufficientAmount(String e) {
		super(e);
	}
}
