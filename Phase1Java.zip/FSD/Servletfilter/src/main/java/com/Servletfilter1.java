package com;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpFilter;


public class Servletfilter1 extends HttpFilter implements Filter {
   
	
	private static final long serialVersionUID = 1L;

	public void init(FilterConfig config) throws ServletException {
		
	}
	

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("Requestreceived at:" + System.currentTimeMillis());
		
		chain.doFilter(request, response);
		System.out.println("Response sent at:" + System.currentTimeMillis());
	}

	public void destroy() {
		
	}
	

}
