public class object {
int x=90;
public static void main (String args []) {
object obj= new object ();
System.out.println(obj.x);
}
}
