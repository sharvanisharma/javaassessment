package java4.movieticket;

public class pptrunnable implements Runnable{
    public void run() 
    { 
        System.out.println("Implementing multithreading concept"); 
    } 
    public static void main(String[] args) 
    { 
        pptrunnable t = new pptrunnable(); 
        Thread t1 = new Thread(t); 
         t1.start(); 
         System.out.println("thread 1");
        Thread t2 = new Thread(t);
        t2.start(); 
        System.out.println("thread 2");
        
    }
} 
    

