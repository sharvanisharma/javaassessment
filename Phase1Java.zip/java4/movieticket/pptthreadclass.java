package java4.movieticket;

class pptthread extends Thread  
{ 
    public void run() 
    { 
        System.out.println("Run method executed "); 
    } 
    public static void main(String[] args) 
    { 
        pptthread t = new pptthread(); 
        t.start(); 
        t.start();
        System.out.println("Main method executed"); 
    } 
} 
