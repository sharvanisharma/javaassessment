package practice1;

public class Address {
	
	
	private long id;
	private String area;
	private int housenumber;
	private String city;
	private int roadnumber;
	
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public int getHousenumber() {
		return housenumber;
	}
	public void setHousenumber(int housenumber) {
		this.housenumber = housenumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getRoadnumber() {
		return roadnumber;
	}
	public void setRoadnumber(int roadnumber) {
		this.roadnumber = roadnumber;
	}
	
	
}
