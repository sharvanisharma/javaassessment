 import java.util.ArrayList;
    public class arraylistcollections {

    public static void main(String[] args){
        ArrayList<String> animals = new ArrayList<>();
        //adding elements
        animals.add("tiger");
        animals.add("lion");
        animals.add("deer");

        System.out.println("ArrayList: " + animals);
    }
}

