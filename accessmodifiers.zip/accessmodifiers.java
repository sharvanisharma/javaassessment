public class accessmodifiers {
        public static void main(String[] args) {
            System.out.println("Java program created in git repository");
        }
        
    }
    
    

