import java.util.Scanner;

public class string {
    public static void main(String[] args) {
        String s = "Sharvani";
        System.out.println(s.length());
        System.out.println(s.indexOf('i'));
        System.out.println(s.contains("kani"));
        System.out.println(s.endsWith("i"));
        System.out.println(s.toUpperCase());
        System.out.println(s.toLowerCase());
    }
    
}
